# Sys-OsPackage
Perl library for installing OS packages and determining if CPAN modules are packaged for the OS
