use strict;
use warnings;
package DZT4;
# VERSION
package DZT4::Inner;
# VERSION
1;
