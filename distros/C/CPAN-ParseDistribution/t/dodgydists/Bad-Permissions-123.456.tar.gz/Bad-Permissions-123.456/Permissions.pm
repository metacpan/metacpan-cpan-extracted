package Bad::Permissions;

$VERSION = 123.456;
