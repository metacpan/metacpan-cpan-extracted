#pragma once
#include "log/log.h"
#include "log/PatternFormatter.h"
