=head1 garbleflux

blah blah

=cut

package Foo;

$VERSION =
