use strict;
use warnings;

$| = 1;

my $x = 1;
my $y = 2;
my $z = $x + $y;

1;

__END__
