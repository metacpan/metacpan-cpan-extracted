#!/usr/bin/env perl
package Test::Cool::invalid;
use Getpt::Typos;
run_for_fun(sub { });
