package Sederhana;

our $VERSION = '2.0.1';

1;

=head1 NAME

Sederhana - A simple module

=cut
