package WebService::Mattermost::V4::API::Resource::Schemes;

use Moo;

extends 'WebService::Mattermost::V4::API::Resource';

1;

