
#ifndef _LNF_FILTER_H
#define _LNF_FILTER_H

#include <libnf_internal.h>
#include <libnf.h>

/* evaluate filter */
//int lnf_filter_eval(lnf_filter_node_t *node, lnf_rec_t *rec);

#endif /* _LNF_FILTER_H */

