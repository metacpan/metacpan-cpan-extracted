$USERID="userid";
$PASSWORD="password";
$PORT=50000;
$HOSTNAME="localhost";
$DATABASE="database";
$PROTOCOL="TCPIP";

$AUTHID="authID";
$AUTHPASS="auth_pass";
$TCUSER="tc_user";
$TCPASS="tc_pass";

$fakedb = "badDB";
$fakeport = $PORT + 1000;
$fakeprotocol = "badProtocol";
$fakehost = "badHost";
$fakeuser = "badID";
$fake_password = "badPassword";
$remotehost = "129.42.58.212";
