use strict;
use warnings;

$| = 1;

print "One\n";
print STDERR "Two\n";
print "Three\n";
print "Four";
print "\n";
print STDERR "Five";
print STDERR "\n";


