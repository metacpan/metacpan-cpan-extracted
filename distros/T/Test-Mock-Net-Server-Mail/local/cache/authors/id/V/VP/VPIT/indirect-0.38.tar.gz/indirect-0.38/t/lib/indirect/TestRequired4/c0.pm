package indirect::TestRequired4::c0;
new X;
1;
