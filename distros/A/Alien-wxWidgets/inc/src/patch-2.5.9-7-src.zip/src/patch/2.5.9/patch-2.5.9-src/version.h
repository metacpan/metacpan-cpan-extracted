/* Print the version number.  */

/* $Id: version.h,v 1.5 2002/05/28 07:24:05 eggert Exp $ */

void version (void);
