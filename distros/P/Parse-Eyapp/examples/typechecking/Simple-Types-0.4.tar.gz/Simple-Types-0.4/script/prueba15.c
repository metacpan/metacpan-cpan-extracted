char x() {
}

int f() {
}
