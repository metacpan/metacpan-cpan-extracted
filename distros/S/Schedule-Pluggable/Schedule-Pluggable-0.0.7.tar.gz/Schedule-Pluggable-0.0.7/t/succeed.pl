#!/usr/bin/env perl

my $sleep = shift;
sleep $sleep if $sleep;
exit 0;
