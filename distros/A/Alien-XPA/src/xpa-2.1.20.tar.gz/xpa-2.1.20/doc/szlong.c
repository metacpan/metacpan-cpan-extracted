#include <stdio.h>

int main(int argc, char **argv)
{
  fprintf(stdout, "%d\n", (int)sizeof(long));
  return 0;
}

