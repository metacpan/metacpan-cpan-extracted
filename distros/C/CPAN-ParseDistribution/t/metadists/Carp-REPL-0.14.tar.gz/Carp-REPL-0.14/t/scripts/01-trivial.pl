#!perl
use strict;
use warnings;

die 'hello world';

