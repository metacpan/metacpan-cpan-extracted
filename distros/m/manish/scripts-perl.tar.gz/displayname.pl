#!/usr/bin/perl -w
print "hi manish how are you \n";

