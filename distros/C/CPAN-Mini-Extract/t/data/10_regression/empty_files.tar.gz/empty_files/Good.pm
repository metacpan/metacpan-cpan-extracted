package Good;

# This is a good file, we should extract this

1;

