#define GENERICSTACK_DEFAULT_LENGTH 0
#include "genericStack.c"
