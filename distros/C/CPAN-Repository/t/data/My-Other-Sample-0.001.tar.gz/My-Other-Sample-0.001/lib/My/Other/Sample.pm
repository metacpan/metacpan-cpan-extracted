use strict;
use warnings;
package My::Other::Sample;
BEGIN {
  $My::Other::Sample::AUTHORITY = 'cpan:GETTY';
}
{
  $My::Other::Sample::VERSION = '0.001';
}
# ABSTRACT: Just another example, just dont care

1;

__END__
=pod

=head1 NAME

My::Other::Sample - Just another example, just dont care

=head1 VERSION

version 0.001

=head1 AUTHOR

Torsten Raudssus <torsten@raudssus.de>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2012 by Torsten Raudssus.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

