
#include <stdint.h>

#include "../stream_chacha20.h"
#include "crypto_stream_chacha20.h"

extern struct crypto_stream_chacha20_implementation
    crypto_stream_chacha20_dolbeau_avx2_implementation;
