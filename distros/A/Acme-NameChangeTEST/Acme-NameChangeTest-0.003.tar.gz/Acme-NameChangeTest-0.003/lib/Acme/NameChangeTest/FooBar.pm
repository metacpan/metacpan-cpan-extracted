use strict;
use warnings;
package Acme::NameChangeTest::FooBar;

=head1 NAME

Acme::NameChangeTest::FooBar - blah blah

1;
