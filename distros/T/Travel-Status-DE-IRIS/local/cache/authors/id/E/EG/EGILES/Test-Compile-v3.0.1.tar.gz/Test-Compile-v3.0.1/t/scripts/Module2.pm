use strict;
use warnings;

sub func1 {
  return 2;
}

1;
