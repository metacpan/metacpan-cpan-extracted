cd /var/www/cpanstats/cgi-bin
perl uploads.cgi
