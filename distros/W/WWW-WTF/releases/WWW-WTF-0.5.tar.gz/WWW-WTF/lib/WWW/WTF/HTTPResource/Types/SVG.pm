package WWW::WTF::HTTPResource::Types::SVG;

use common::sense;

use Moose::Role;

1;
