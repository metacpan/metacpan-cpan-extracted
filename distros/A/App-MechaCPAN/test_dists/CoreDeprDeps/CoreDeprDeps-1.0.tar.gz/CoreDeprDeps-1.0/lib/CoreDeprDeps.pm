package #hide from CPAN
  CoreDeprDeps;

use strict;
use 5.008_005;
our $VERSION = '0.01';

1;
# ABSTRACT: Blah blah blah
