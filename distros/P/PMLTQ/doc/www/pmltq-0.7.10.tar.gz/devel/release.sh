#!/bin/bash

version=$(grep '^Version:' RELEASE | cut -f2 -d' ')
tar czf "pmltq-${version}.tar.gz"  --no-recursion $(svn list -R)
