plugin.video.mhfs
================

Kodi Video Addon for MHFS
For Kodi Matrix and above releases

Version 0.1.0 Initial release for Matrix
