use utf8;
package Test::Schema;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces;


# Created by DBIx::Class::Schema::Loader v0.07043 @ 2016-12-17 10:11:48
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:9PyU7R4TJ4+fZSZe2mNwVQ


# You can replace this text with custom code or comments, and it will be preserved on regeneration
1;
