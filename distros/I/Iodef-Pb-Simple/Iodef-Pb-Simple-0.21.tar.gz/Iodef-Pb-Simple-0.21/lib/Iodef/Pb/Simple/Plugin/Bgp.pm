package Iodef::Pb::Simple::Plugin::Bgp;
use base 'Iodef::Pb::Simple::Plugin';

use strict;
use warnings;

sub process{
    my $self = shift;
    my $data = shift;
    my $iodef = shift; 
}

1;
