package OtherThing;

sub new {
    bless {}, 'OtherThing';
}

1;
