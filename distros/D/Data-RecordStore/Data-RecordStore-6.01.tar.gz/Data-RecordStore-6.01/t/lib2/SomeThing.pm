package SomeThing;

@ISA = ();

1;
