package WWW::WTF::HTTPResource::PDF;

use common::sense;

use Moose::Role;

1;
