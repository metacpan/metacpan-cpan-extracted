use strict;
use warnings;

use Test2::V0;
use Try::Tiny;
use File::Which qw(which);
use Rose::DB::Object::Loader;

use lib qw(lib t);

use DBI;
use Data::Dumper;
use DBD::Mock::Session::GenerateFixtures;
use Sub::Override;
use File::Path qw(rmtree);
use Test::mysqld;

use MyDatabase qw(build_mysql_db populate_test_db);

BEGIN {
    my $mysqld_check = which('mysqld') || which('mariadb');

    if ( !$mysqld_check ) {
        plan skip_all => "MariaDB is not installed or not in PATH. Please run 'sudo apt-get install -y mariadb-server mariadb-client libmariadb-dev'";
    }

}

my $db = DB->new(
    domain => 'mysql_test',
    type   => 'mysql_test',
);
my $loader = Rose::DB::Object::Loader->new(
    db           => $db,
    class_prefix => 'DB'
) or die "Failed to create loader: $@";

$db->dbh()->do("SET SESSION sql_mode=''");
build_mysql_db( $db->dbh );
populate_test_db( $db->dbh );
my $obj = DBD::Mock::Session::GenerateFixtures->new( { dbh => $db->dbh() } );

# $obj->get_dbh()->{PrintError} = 0;

my $sql_user_login_history = <<"SQL";
-- comment
/* foo 
bar */
INSERT INTO user_login_history (user_id) VALUES (?)
SQL

my $failed_sql_user_login_history = <<"SQL";
INSERT INTO user_login_history (id) VALUES (?)
SQL

subtest 'upsert generate mock data' => sub {

    $obj->get_dbh()->begin_work();
    my ( $r, $r_2 );

    # my $success = 1;
    my $not_ok;
    my $ok = 1;
    try {
        my $sth = $obj->get_dbh()->prepare($sql_user_login_history);
        $r   = $sth->execute(1) or die $obj->get_dbh()->err();
        $r_2 = $sth->execute(2) or die $obj->get_dbh()->err();
    }
    catch {
        $not_ok = $obj->get_dbh()->err();
        $ok     = 0;
        $obj->get_dbh()->rollback();
    };

    $obj->get_dbh()->commit() if $ok;

    is( $r,   1, 'one row inserted is ok' );
    is( $r_2, 1, 'one second inserted is ok' );

};

subtest 'failled singe trans data' => sub {
    $obj->get_dbh()->begin_work();
    my $ok = 1;

    my $r_3;
    $ok = 1;
    my $error     = undef;
    my $error_msg = undef;
    try {
        my $sth_2 = $obj->get_dbh()->prepare($failed_sql_user_login_history);
        $r_3 = $sth_2->execute(1)
          or die 'can not commit' . $obj->get_dbh()->err();
    }
    catch {
        $ok        = 0;
        $error     = $obj->get_dbh()->err();
        $error_msg = $obj->get_dbh()->errstr();
        $obj->get_dbh()->rollback();

    };

    $obj->get_dbh()->commit() if $ok;
    ok( $error, 'rollback is ok' );
    is( $error,     '1062',                                  'err code is ok' );
    is( $error_msg, "Duplicate entry '1' for key 'PRIMARY'", 'err mesaage is ok' );
};

subtest 'upsert generate mock data for nested transactions both are ok' => sub {
    my $dbh = $obj->get_dbh();

    try {
        $dbh->begin_work();
        my $sth = $dbh->prepare($sql_user_login_history);
        my $r   = $sth->execute(3) or die $obj->get_dbh()->err();
        try {
            my $sth_2 = $dbh->prepare($sql_user_login_history);
            my $r_2   = $sth_2->execute(4) or die $dbh->err();
            is( $r_2, 1, 'one second inserted is ok' );
        }
        catch {
            $dbh->rollback();
        };
        $dbh->commit();
        is( $r, 1, 'one row inserted is ok' );
    }
    catch {
        $obj->get_dbh()->rollback();
    };

};

subtest 'upsert generate mock data for nested transactions - big trans is not ok' => sub {
    my $error_big     = undef;
    my $error_big_msg = undef;
    my $error_small   = undef;

    my $dbh = $obj->get_dbh();
    my $ok  = 1;
    try {
        $dbh->begin_work();
        my $sth = $dbh->prepare($failed_sql_user_login_history);
        my $r   = $sth->execute(3) or die $dbh->get_dbh()->err();
        try {
            my $sth_2 = $dbh->prepare($sql_user_login_history);
            my $r_2   = $sth_2->execute(4) or die $dbh->err();
        }
        catch {
            $ok          = 0;
            $error_small = $dbh->errstr();
            $dbh->rollback();
        };
    }
    catch {
        $ok            = 0;
        $error_big     = $dbh->err();
        $error_big_msg = $dbh->errstr();
        $dbh->rollback();
    };

    $dbh->commit() if $ok;

    ok( $error_big, 'error in the big try/catch is ok' );
    is( $error_big,     '1062',                                  'err code is ok' );
    is( $error_big_msg, "Duplicate entry '3' for key 'PRIMARY'", 'err mesaage is ok' );
};

subtest 'upsert generate mock data for nested transactions - small trans is not ok' => sub {
    my $error_big        = undef;
    my $error_small      = undef;
    my $error_code_small = undef;

    my $dbh = $obj->get_dbh();
    my $ok  = 1;
    try {
        $dbh->begin_work();
        my $sth = $dbh->prepare($sql_user_login_history);
        my $r   = $sth->execute(3) or die $dbh->err();
        try {
            my $sth_2 = $dbh->prepare($failed_sql_user_login_history);
            my $r_2   = $sth_2->execute(4) or die $dbh->err();
        }
        catch {
            $error_small      = $dbh->errstr();
            $error_code_small = $dbh->err();

            $ok = 0;
            $dbh->rollback();
        };
    }
    catch {
        $error_big = $dbh->err();
        $dbh->rollback();
    };

    $dbh->commit() if $ok;
    ok( $error_small, 'error in the small try/catch is ok' );
    is( $error_small,      "Duplicate entry '4' for key 'PRIMARY'", 'err mesage is ok' );
    is( $error_code_small, 1062,                                    'erro code is ok' );
};

subtest 'test mysql proc call' => sub {
    my $proc_call = <<"SQL";
        CALL pr_user_login_history(?)
SQL
    my $sth_proc = $db->dbh()->prepare($proc_call);
    $sth_proc->execute(1);
    my $proc_result = $sth_proc->fetchrow_hashref();
    my $expected    = {
        'user_id'  => 1,
        'id'       => 1,
        'login_at' => '2026-03-08 19:08:04'
    };
    is( $proc_result->{user_id}, 1 );
};

done_testing();
