use DBI;
  use strict;  
# Open a connection 
  my $string = "dbi:DB2:DATABASE=test;hostname=10.45.6.9;port=50000;authentication=kerberos;targetprincipal=HOST/waldevdbcwtst03.dev.rocketsoftware.com@DEV.ROCKETSOFTWARE.COM";
  my $dbh = DBI->connect($string,  "", "", {RaiseError => 1});
# use VALUES to retrieve value from special register
  my $stmt = "Values CURRENT TIMESTAMP";
  my $sth = $dbh->prepare($stmt);
  $sth->execute();
# associate variables with output columns...
  my $col1;
  $sth->bind_col(1,\$col1);
  while ($sth->fetch) { print "Today is: $col1\n"; }
  $sth->finish();
  $dbh->disconnect();
  
  
  Abstract: SQLGetConnectAttr() function call with SQL_ATTR_GET_LATEST_MEMBER_NAME taking time due to getaddrinfo taking more time.


  Description:

SQLGetConnectAttrW api  with SQL_ATTR_GET_LATEST_MEMBER_NAME option takes upto 6ms while it takes .4 ms or even lesser in good case.

[1561643972.281175 - 06/27/2019 13:59:32.281175] 49715	SQLGetConnectAttrW( hDbc=0:1, fOption=SQL_ATTR_GET_LATEST_MEMBER_NAME, pvParam=&0fffffffffff5910, cbParamMax=64, pcbParam=&0fffffffffff5840 )

[1561643972.287257 - 06/27/2019 13:59:32.287257] SQLGetConnectAttrW( pvParam="MLT3", pcbParam=8 )
49826    <--- SQL_SUCCESS   Time elapsed - +6.091000E-003 secon

The delay is due to using the hostname in the affinitylist in the db2dsdriver.cfg file.
CLI driver call sthe getaddrinfo() api to convert the host name to IP address and comapre with the
current connected member ip. getaddrinfo() is taking more time.



Workaround : Use the IP address or put the hostname to ip resolution in /etc/hosts.  



Abstract : SQLCreatePkg API is failing with SQL0031C error.

Description :

SQLCreatePkg() API called wtih just bind or list file name without providing he full pathname, with SQL0031C error.

SQLCreatePkgW( hDbc=0:1, szBindFileNameIn="@db2cli.lst", cbBindFileNameIn=-3, szBindOpts="ACTION=REPLACE; KEEPDYNAMIC=YES; RELEASE=COMMIT; REOPT=ONCE; ENCODING=UNICODE; BLOCKING=ALL; COLLECTION=COLID773X2; MSGFILE=\\wdflbmd22311\sapmnt\N75\SYS\global\bindout.log; GENERIC=APPLCOMPAT V12R1M501", cbBindOpts=-3 )
    ---> Time elapsed - +0,000000E+000 seconds

SQLCreatePkgW( )
    <--- SQL_ERROR   Time elapsed - +0,000000E+000 seconds
	
SQLGetDiagFieldW( pDiagInfo="[IBM][CLI Driver][DB2] SQL0031C  File "D:\SLHA\work\ld2295\ibmcase\/usr/sap/N75/SYS/globa" could not be opened.

This is because install path on windows returned has '/' in it in place of '\', hence SQLCreatePkg() throwing error.

ex:
  Install Path:   D:/usr/sap/N75/SYS/global\\db2\WINDOWS_AMD64\db2_clidriver\

APAR 	IT29857 SQLCreatePkg API is failing with SQL0031C error.
APAR    IT29781 SQLGetConnectAttr() function call with SQL_ATTR_GET_LATEST_MEMBER_NAME taking time due to getaddrinfo taking more time  
APAR    IT29781 DB2DSDCFGFILL COMMAND WITH -MIGRATECLIINIFOR.NET OPTION IS NOT MIGRATING ALL THE ENTIRES IN DB2CLI.INI TO DB2DSDRIVER.CFG
APAR    IT28771 SQLGETTYPEINFO WITH  SQL_BOOLEAN  IS NOT RETURNING ANY RESULT
APAR    IT29206 SQLSetConnectAttrW() with SQL_ATTR_SESSION_GLOBAL_VAR  attribute is not working as expected
