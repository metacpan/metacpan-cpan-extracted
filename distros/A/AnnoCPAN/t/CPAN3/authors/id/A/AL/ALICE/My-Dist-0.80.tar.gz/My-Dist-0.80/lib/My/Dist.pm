package My::Dist;

$VERSION = '0.80';

=head1 NAME

My::Dist

=head1 SYNOPSYS

    use My::Dist;

    # this is a second verbatim paragraph, followed by several blank or
    # almost blank lines

   




=head1 DESCRIPTION

The purpose here is to see what happens with multiple verbatim paragraphs.

Let's put the original paragraph (with a minor modification) back for fun:

This is my module. There are many like it, but this one is mine.

=cut

1;

