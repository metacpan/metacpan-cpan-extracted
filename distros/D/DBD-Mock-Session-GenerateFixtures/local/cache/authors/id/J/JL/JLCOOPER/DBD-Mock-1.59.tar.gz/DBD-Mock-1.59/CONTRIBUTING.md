# Contributing to the DBD::Mock module

If you'd like to contribute to the DBD::Mock module then I suggest you
use one of the following ways:

* Post a ticket to the [RT](https://rt.cpan.org/Public/Dist/Display.html?Name=DBD-Mock)
queue for the module.

* Raise an issue in the [GitLab project](https://gitlab.com/scrapheap/DBD-Mock/issues)

* If you have actual code to commit then make a Merge Request to the [GitLab project](https://gitlab.com/scrapheap/DBD-Mock)
