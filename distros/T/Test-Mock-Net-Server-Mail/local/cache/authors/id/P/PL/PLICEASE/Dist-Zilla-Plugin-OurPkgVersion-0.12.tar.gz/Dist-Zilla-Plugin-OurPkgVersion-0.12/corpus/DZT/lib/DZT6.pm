package DZT6;
use strict;
use warnings;
#VERSION
1;
