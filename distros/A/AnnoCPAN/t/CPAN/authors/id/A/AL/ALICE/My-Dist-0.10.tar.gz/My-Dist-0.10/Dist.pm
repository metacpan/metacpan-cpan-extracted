package My::Dist;

$VERSION = '0.10';

=head1 NAME

My::Dist

=head1 SYNOPSYS

    use My::Dist;

=head1 DESCRIPTION

This is my dist. There are many like it, but this one is mine.

=cut

1;

