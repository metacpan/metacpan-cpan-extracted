
1: 1  1  1
   -  ^   
found Number where operator expected (previous token underlined)

1: 1  1  1
      -  ^
found Number where operator expected (previous token underlined)
1 1 1
