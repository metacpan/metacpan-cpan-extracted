package MPM::<!-- cgi: ProjectName -->::<!-- cgi: ControllerName -->; # $Id$
use strict;

=head1 NAME

MPM::<!-- cgi: ProjectName -->::<!-- cgi: ControllerName --> - controller /<!-- cgi: ControllerName -->.mpm

=head1 VERSION

Version <!-- cgi: ProjectVersion -->

=head1 DESCRIPTION

Blah-Blah-Blah

=cut

use vars qw($VERSION);
our $VERSION = <!-- cgi: ProjectVersion -->;

sub record {
    (
        -uri      => ['locarr','<!-- cgi: ControllerName -->',
                        ['/<!-- cgi: ControllerName -->.mpm',lc('/<!-- cgi: ControllerName -->.mpm')]
                     ],
        -type     => \&hType,
        -response => \&hResponse,
    )
}

sub hType {
    shift->r->content_type('text/plain; charset=<!-- cgi: DefaultCharset -->');
    return Apache2::Const::OK;
}
sub hResponse {
    my $m = shift;
    my $r = $m->r;
    
    my $data = <<EOF;
Controller : <!-- cgi: ControllerName -->
Package    : MPM::<!-- cgi: ProjectName -->::<!-- cgi: ControllerName -->
EOF

    $r->set_content_length(length($data));
    $r->print($data);
    $r->rflush();
    
    return Apache2::Const::OK;
}

1;
