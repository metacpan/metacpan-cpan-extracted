test (int n)
{
	while (1) {
		if (1>0) {
			break;
		}
		else if (2> 0){
			continue;
		}
	}
}
