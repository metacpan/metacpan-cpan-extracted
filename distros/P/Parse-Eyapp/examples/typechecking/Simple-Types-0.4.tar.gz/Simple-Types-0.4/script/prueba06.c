int a,b,e[10][20];

g() {}

int f(char c) {
char d[20];
 c = 'X';
 g(e[d], 'A'+c);
 { 
   int d;
   d = a + b;
 }
 c = d * 2;
 return c;
}

