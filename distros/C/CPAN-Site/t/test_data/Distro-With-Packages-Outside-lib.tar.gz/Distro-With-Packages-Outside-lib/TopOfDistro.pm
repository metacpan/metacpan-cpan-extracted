# This file is used in the CPAN::Site test suite.
# This file is located in the lib/ directory of a distro, and so
# its package should be registered.
#
package TopOfDistro;
our $VERSION = '0.01';

1;