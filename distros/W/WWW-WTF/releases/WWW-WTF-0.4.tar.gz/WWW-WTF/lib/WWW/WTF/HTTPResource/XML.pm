package WWW::WTF::HTTPResource::XML;

use common::sense;

use Moose::Role;

1;
