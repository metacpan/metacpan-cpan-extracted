use strict;
use warnings;
package Acme::NameChangeTest::Foobar;

=head1 NAME

Acme::NameChangeTest::Foobar - blah blah

1;
