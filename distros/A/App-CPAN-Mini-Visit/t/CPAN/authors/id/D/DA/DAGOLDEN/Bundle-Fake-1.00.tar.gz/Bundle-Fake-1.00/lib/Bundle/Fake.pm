package Bundle::Fake;

$VERSION     = "1.00";

1; # modules must be true

=head1 NAME

=head1 CONTENTS

Bogus::Pass

=cut

