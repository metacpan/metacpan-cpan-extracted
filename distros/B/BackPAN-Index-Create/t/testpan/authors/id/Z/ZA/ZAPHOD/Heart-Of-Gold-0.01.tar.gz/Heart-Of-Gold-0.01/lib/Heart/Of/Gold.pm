use strict;
use warnings;
package Heart::Of::Gold;

# ABSTRACT: It's just this ship, you know.

1;
