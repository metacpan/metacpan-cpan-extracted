package Sederhana::Juga;

1;

=head1 NAME

Sederhana::Juga - Another simple module

=cut
