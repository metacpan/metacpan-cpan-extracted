package Foo;
our $VERSION = '1.0';
1;
