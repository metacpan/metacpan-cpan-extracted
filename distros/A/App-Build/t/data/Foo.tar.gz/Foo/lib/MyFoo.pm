package MyFoo;

use strict;

# dummy, to see how it is handled

1;
