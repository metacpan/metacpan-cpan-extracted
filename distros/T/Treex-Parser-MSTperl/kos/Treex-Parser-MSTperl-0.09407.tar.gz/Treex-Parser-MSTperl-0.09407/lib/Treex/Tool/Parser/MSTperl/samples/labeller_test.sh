#!/bin/bash
./test_labeller_tsv.pl sample_test.tsv sample.Lmodel sample.config $@
