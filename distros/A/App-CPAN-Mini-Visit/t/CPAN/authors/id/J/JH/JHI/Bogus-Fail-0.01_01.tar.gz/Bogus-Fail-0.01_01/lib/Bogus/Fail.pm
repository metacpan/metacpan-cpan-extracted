package Bogus::Fail;

$VERSION     = "0.01";

1; # modules must be true

