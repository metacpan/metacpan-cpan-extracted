CREATE TABLE sys_error (
 error_id      char(12) not null,
 code          varchar(10) not null,
 type          varchar(20),
 user_msg      text,
 system_msg    text,
 package       varchar(40) not null,
 filename      varchar(60) not null,
 line          smallint not null,
 action        varchar(25),
 user_id       %%USERID_TYPE%%,
 session_id    varchar(32),
 browser       varchar(75),
 referer       varchar(150),
 error_time    %%DATETIME%%,
 url           varchar(150),
 notes         text,
 primary key   ( error_id )
)

