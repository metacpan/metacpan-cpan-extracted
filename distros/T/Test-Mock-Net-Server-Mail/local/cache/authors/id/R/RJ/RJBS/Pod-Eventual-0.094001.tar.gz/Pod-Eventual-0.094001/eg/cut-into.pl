
This should be an alien line.

=cut
This comes in the same paragraph as the =cut.

This comes after a =cut that is the first pod command in the document.

=cut

This is a text para after a second cut command.

