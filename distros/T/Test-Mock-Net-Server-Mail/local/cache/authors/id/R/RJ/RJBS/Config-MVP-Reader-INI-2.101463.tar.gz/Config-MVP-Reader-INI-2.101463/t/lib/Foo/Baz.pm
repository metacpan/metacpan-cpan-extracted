package Foo::Bar;
sub mvp_multivalue_args { qw(multi) }
1;
