package App::GitAutofixup;

our $VERSION = 0.001000;

=head1 NAME

App::GitAutofixup - create fixup commits for topic branches

=head1 DESCRIPTION

This is a stub module, see F<git-autofixup> for details of the app.

=head1 AUTHOR

Jordan Torbiak

=head1 LICENSE

Artistic License 2.0

=cut

1;
