package #hide from CPAN
  NoDeps;

use strict;
use 5.008_005;
our $VERSION = '1.0';

1;
# ABSTRACT: Blah blah blah
