package Mojo::LoaderTest::A;
use Mojo::Base -base;

1;
