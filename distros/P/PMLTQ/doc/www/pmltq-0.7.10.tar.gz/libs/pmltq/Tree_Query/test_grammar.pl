#!/usr/bin/perl

use FindBin;
use File::Spec;
use lib $FindBin::RealBin;
use Grammar;
use Treex::PML;
my ($what, $string)=@ARGV;
my $parser = Tree_Query::Grammar->new();
my $result = $parser->$what($string);
use Data::Dumper;
print Dumper($result);

