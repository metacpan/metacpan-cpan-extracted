package Test50::FooTab;

use strict;
use warnings;

use YAWF::Object;

our @ISA = ('YAWF::Object','Test50::DB::Result::Footab');

use constant TABLE => 'Footab';

1;
