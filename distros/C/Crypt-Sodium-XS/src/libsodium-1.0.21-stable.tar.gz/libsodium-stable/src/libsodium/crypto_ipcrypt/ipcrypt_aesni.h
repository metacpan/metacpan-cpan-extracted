#ifndef ipcrypt_aesni_H
#define ipcrypt_aesni_H

#include "implementations.h"

extern struct ipcrypt_implementation ipcrypt_aesni_implementation;

#endif
