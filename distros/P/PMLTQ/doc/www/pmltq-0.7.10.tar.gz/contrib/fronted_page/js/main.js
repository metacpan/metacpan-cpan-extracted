// titles on icons
$.fn.tipsy.defaults.opacity = 1.0;
$('.icon').tipsy({gravity: 's'});
$('a[title]').tipsy({gravity: $.fn.tipsy.autoWE});

$('#services h3.has-abstract').hover(function(){
    $(this).addClass('hover');
}, function(){
    $(this).removeClass('hover');
}).click(function(){
    var $this = $(this);
    $this.removeAttr('original-title');
    $this.data('tipsy').hide();
    $this.siblings('.abstract')
        .slideToggle('fast', function() {
            $this.children('span').toggle();
        });
}).tipsy({gravity: 's', html: true, title: function(){
    return $(this).children('.more-button:visible').size() > 0 ?  "Show details about this treebank &hellip;" : "Hide details &hellip;";
}});
