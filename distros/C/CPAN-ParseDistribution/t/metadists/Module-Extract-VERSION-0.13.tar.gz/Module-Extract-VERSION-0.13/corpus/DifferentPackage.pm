package DBI;

$DBI::PurePerl::VERSION = 1.23;

1;
