package Doo::Dar;

use strict;
use warnings;
use vars qw($VERSION);

$VERSION = '0.01';

'Doo Dar!'

__END__
