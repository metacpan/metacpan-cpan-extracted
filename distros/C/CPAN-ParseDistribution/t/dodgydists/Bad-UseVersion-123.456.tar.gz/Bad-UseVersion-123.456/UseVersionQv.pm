package Bad::UseVersionQv;

use version qw(qv nonsense); $VERSION = qv('0.0.3');
