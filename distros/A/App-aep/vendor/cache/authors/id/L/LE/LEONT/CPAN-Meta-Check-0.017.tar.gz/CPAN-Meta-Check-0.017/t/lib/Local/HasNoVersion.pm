package Local::HasNoVersion;
# no $VERSION declaration implies undef
1;
