% NLOPT_GN_AGS: global derivative-free optimization
% with nonlinear inequality constraints.
%
% See nlopt_minimize for more information.
function val = NLOPT_GN_AGS
  val = 42;
