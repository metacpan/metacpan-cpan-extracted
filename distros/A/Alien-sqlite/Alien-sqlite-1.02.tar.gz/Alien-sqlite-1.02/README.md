# perl-alien-sqlite
Perl Alien package to compile sqlite
