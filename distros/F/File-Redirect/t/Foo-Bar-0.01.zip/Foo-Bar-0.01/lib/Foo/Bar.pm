package Foo::Bar;

sub foo { 42 }

1;
