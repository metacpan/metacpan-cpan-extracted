#include "libdontpanic.h"

int answer () {
  return 42;
}

