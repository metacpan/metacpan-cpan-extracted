package My::Dist;

$VERSION = '0.20';

=head1 NAME

My::Dist

=head1 SYNOPSYS

    use My::Dist;

=head1 DESCRIPTION

This is a dist. There are many like it, 
but this one is mine.

The purpose here is to see the effect having two dists with the same 
name and version in different author directories.

=cut

1;

