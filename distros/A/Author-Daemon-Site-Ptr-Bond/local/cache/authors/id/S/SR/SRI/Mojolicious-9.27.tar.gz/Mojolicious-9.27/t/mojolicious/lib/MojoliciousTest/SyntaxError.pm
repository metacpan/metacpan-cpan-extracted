package MojoliciousTest::SyntaxError;
use Mojo::Base 'Mojolicious::Controller';

sub foo {

1;
