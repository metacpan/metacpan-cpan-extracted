package MyTest;
use 5.012;
use Test::Catch;
use XS::libpanda;

XS::Loader::load();

1;
