package Phony::FAIL;
use 5.6.1;
use strict;
use warnings;
use Exporter ();
our @ISA = ( qw| Exporter | );
our $VERSION = '0.01';
our @EXPORT_OK = ();

sub hello { return "hello world" };

1;

