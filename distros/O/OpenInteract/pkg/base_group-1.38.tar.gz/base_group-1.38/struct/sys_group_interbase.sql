CREATE TABLE sys_group (
 group_id      %%INCREMENT%%,
 name          varchar(30) not null,
 notes         blob,
 primary key   ( group_id )
)
