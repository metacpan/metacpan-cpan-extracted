#!/usr/bin/env perl
package Test::Cool::help;
use Getopt::App;
run(sub { print extract_usage });

__END__

=head1 SYNOPSIS

help me

=cut
