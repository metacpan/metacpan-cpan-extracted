package NpsSDK::Version;

use warnings; 
use strict;

our $VERSION = 'Perl SDK Version: 1.7';

1;
