# This file is used in the CPAN::Site test suite.
# This file is located in the inc/ directory of a distro, and so
# its package should NOT be registered.
#
package DoNotRegister::InsideInc;
our $VERSION = '0.01';

1;