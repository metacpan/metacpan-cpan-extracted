package Alien::libbar;

use strict;
use warnings;

sub dynamic_libs
{
  'corpus/unix/usr/lib/libbar.so.1.2.3';
}

1;
