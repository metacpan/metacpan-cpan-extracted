package A::NoVersion;

return 1;