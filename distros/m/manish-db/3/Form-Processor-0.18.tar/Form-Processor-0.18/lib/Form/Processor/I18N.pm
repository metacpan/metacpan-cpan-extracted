package Form::Processor::I18N;
use strict;
use warnings;
use base qw(Locale::Maketext);

1;


