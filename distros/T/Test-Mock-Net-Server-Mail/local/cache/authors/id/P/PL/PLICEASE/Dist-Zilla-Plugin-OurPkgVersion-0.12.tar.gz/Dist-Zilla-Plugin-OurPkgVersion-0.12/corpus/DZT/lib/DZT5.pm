package DZT5;
use strict;
use warnings;
# VERSION: foo
1;
