package {{$dist->name =~ s{-}{::}gr}}::RankedDictionaries;
use strict;
use warnings;
use Data::Password::zxcvbn::RankedDictionaries::Common;
use Data::Password::zxcvbn::RankedDictionaries::{{(split /-/,$dist->name)[-1]}};
# VERSION
# ABSTRACT: ranked dictionaries for common {{(split /-/,$dist->name)[-1]}} words

=head1 DESCRIPTION

This merges the common dictionaries from the C<Data::Password::zxcvbn>
distribution, and {{(split /-/,$dist->name)[-1]}} dictionaries.

=cut

our %ranked_dictionaries = (
    %Data::Password::zxcvbn::RankedDictionaries::Common::ranked_dictionaries,
    %Data::Password::zxcvbn::RankedDictionaries::{{(split /-/,$dist->name)[-1]}}::ranked_dictionaries,
);

1;
