# Contributing to moku pona

The simplest way to contribute is to contact me by mail:
[alex@gnu.org](mailto:alex@gnu.org), or take a look at the
[alternatives](https://alexschroeder.ch/wiki/Contact).

I prefer [patches via email](https://git-send-email.io/), but [GitHub
works as well](https://github.com/kensanata/moku-pona).

As for issues, your options are:

* just send an email

* create a page on my [Software Wiki](https://alexschroeder.ch/software/Moku%20Pona)
