package LWP::DebugFile;

our $VERSION = '6.36';

# legacy stub

1;
