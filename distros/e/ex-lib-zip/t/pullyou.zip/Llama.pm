#!perl -w
use strict;

package Llama;
sub name {
  "llama";
}
1;

# Repeating stuff so this will deflate rather than store
# Repeating stuff so this will deflate rather than store
# Repeating stuff so this will deflate rather than store
# Repeating stuff so this will deflate rather than store
# Repeating stuff so this will deflate rather than store
# Repeating stuff so this will deflate rather than store
