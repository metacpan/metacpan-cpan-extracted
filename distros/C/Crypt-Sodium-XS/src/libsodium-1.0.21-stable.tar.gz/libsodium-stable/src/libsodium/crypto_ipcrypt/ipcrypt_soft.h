#ifndef ipcrypt_soft_H
#define ipcrypt_soft_H

#include "implementations.h"

extern struct ipcrypt_implementation ipcrypt_soft_implementation;

#endif
