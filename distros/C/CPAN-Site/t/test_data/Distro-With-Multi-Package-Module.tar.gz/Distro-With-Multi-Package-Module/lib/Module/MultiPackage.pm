# This file is used in the CPAN::Site test suite.
# This file contains multiple package declarations which
# should all be registered.
#
package Module::MultiPackage;
BEGIN {
  $Module::MultiPackage::VERSION = '0.01';
}

{
  # this package should be hidden
  package
    Module::MultiPackage::SubPackageOne;

  BEGIN {
    $Module::MultiPackage::SubPackageOne::VERSION = '0.011';
  }
}

{
  # so should this package
  package
    Module::MultiPackage::SubPackageTwo;
  BEGIN {
    $Module::MultiPackage::SubPackageTwo::VERSION = '0.012';
  }
}

1;
