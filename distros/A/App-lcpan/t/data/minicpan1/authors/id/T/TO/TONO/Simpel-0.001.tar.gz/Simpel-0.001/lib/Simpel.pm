package Simpel;

our $VERSION = '0.001';

1;

=head1 NAME

Simpel - A modest module

=cut
