package TestError;

use Moose;
use strict;
use warnings;

extends "Throwable::Error";

1;
