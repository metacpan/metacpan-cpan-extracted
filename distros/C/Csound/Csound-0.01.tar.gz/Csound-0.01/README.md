# Perl module Csound

Create Csound scores, instruments and orchestras.
