# Pipe::Tube::Csv - Perl module

## Release

* Update the VERSION in all the files
* Update the Chnages file
* git tag

```
perl Makefile.PL
make
make test
make manifest
make dist
```
