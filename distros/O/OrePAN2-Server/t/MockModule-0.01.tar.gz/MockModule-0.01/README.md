# NAME

MockModule - It's new $module

# SYNOPSIS

    use MockModule;

# DESCRIPTION

MockModule is ...

# LICENSE

Copyright (C) Hiroyuki Akabane.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

Hiroyuki Akabane <hirobanex@gmail.com>
