#!/bin/bash

# [1] This script registers the Windows NT/2k/XP Dash service
#     using cygwin cygrunsrv and cygwin perl.
# [2] Beware of Windows service naming quirks like special characters or name
#     length! If needed, overide default service name as script input parameter.

service=rrachelxdashPC

if [ -n "$1" ]
then
 service=$1
fi

echo Stoping $service, if any running.
sc stop $service
echo Deleting $service, if any exists.
sc delete $service

echo Registration result:
cygrunsrv --install $service --path /bin/perl --args /home/Ex1S1R/r.rachel@xdash_PC/receiver --disp "xDash agent / r.rachel@xdash/PC" --desc "Example of event consumer" --neverexits --shutdown --user "NT AUTHORITY\NetworkService" --passwd "xdash" -e CYGWIN=ntsec
sc failure $service  reset= 0 actions= restart/10000

sc query $service
sc qfailure $service

