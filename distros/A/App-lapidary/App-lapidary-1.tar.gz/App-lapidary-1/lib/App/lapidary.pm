package App::lapidary;

our $VERSION = 1.00;

=head1 NAME

lapidary - Determine the read coverage and identity to a protein database using diamond

=head1 DESCRIPTION

This is a stub module, see F<script/lapidary> for details of the app.

=head1 AUTHOR

Samuel Bloomfield

=head1 LICENSE

GPL_3

=cut

1;