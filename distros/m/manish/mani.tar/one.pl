#!/usr/bin/perl -w
print "enter your name";
chomp($name=<STDIN>);
print "my name is $name \n";

