package Bad::UseVars;

use vars qw($VERSION); $VERSION = 789;
