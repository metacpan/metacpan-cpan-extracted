use strict;
use warnings;
package Dzil::Test;

# ABSTRACT: Dzil Test

sub new {
    return bless {}, shift;
}
sub ret {
    return 55;
}
1;
