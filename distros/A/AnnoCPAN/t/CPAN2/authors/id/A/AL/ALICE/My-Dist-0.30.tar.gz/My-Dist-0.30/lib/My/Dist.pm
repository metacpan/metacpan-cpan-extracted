package My::Dist;

$VERSION = '0.30';

=head1 NAME

My::Dist

=head1 SYNOPSYS

    use My::Dist;

=head1 DESCRIPTION

The purpose of this test is to see the effect having moving a paragraph.

This is a dist. There are many like it, 
but this one is mine.

=cut

1;

