# This file is used in the CPAN::Site test suite.
# This file is located in the t/ directory of a distro, and so
# its package should NOT be registered.
#
package DoNotRegister::InsideTLib;
our $VERSION = '0.01';

1;