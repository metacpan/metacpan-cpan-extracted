package Bogus::OSUnsupported;

$VERSION     = "0.01";

1; # modules must be true

