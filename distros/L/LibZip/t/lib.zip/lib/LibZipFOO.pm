
package LibZipFOO ;

sub test {
  return( 'OK' , join(" ", @_) ) ;
}

1;

