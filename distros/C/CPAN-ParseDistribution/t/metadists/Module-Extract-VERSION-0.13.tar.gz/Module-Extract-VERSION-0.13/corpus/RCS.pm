#!/usr/bin/perl

print "Hello world!\n";

$VERSION = sprintf "%d.%02d", q$Revision: 1.23$ =~ m/(\d+)/g;

1;
