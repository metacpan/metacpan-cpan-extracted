package Bad::Unsafe;

$VERSION = `echo 123.456`;
