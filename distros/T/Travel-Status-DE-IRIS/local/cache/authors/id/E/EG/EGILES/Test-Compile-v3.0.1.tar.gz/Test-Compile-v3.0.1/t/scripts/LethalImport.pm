package t::scripts::LethalImport;

sub import { die "All die"; }

1;
