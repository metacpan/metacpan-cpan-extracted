#!/bin/bash
./test_tsv.pl sample_test.tsv sample.model sample.config