#!/bin/bash

f1="$1"
f2="$2"

colop.pl -e 'sprintf("%-50s\t",$_[0]).join("\t",@_[1..4],($_[3] - $_[4]))' \
  <( tabify "$f1" | cut -f2 ) \
  <( tabify "$f1" | cut -f3 ) \
  <( tabify "$f2" | cut -f3 ) \
  <( tabify "$f1" | cut -f3 | time2sec.pl) \
  <( tabify "$f2" | cut -f3 | time2sec.pl) \
  |  sed 's/##/#/'
