use strict;
use warnings;
package Local::StaticInstall;
our $VERSION = '0.001';
1;

# ABSTRACT: Fake dist with static install for testing lazy

__END__

=pod

=encoding UTF-8

=head1 NAME

Local::StaticInstall - Fake dist with static install for testing lazy

=head1 VERSION

version 0.001

=head1 AUTHOR

Olaf Alders <olaf@wundercounter.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2018 by Olaf Alders.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
