%commit = (
  "0b2d9d33df9eebbbfea07fab53019f63571183c6" => {
    author => "Example Author <author\@example.com> 1405523491 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    parent => [
      "32defe32456a053a9c391cdcf9a4292af6d3c80a"
    ],
    subject => "g\303\263\303\260ur dagur (is)",
    tree => "b090e309a779f2ea76260d10abd027b08fb36362"
  },
  "1f2e387e072680656acac623ea04e1b2b054e8c7" => {
    author => "Example Author <author\@example.com> 1405523494 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    parent => [
      "f6812d818e65423551c0eb7ac899dbea5311eb56"
    ],
    subject => "\343\201\223\343\202\223\343\201\253\343\201\241\343\201\257 (ja)",
    tree => "822aed1f11e71b48d14c899d209b0dca92a08ec8"
  },
  "255a1a6e669ab3b04fd53d26c3ffcdfe16d83a3e" => {
    author => " <author\@example.com> 1405523483 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    parent => [],
    subject => "hello (en)",
    tree => "fa85af1dc631f3f8d977aafe0253b1d02eb2c4c7"
  },
  "32defe32456a053a9c391cdcf9a4292af6d3c80a" => {
    author => "Example Author <author\@example.com> 1405523488 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    parent => [
      "6015b6a34038fd16fa8393a066493e6fcc9a174a",
      "6ba823ece3063b52e1d44cdde497332645fb49e0"
    ],
    subject => "Merge branch 'slave'",
    tree => "a319709ffcce3607d752ca412bd1db7f932cce81"
  },
  "469cc551a1323d8a0285efa7047d72d99013fd36" => {
    author => "Example Author <author\@example.com> 1405523505 +0100",
    body => "# tag 'v1.1.0'\nsigned tag\n\n# gpg: Signature made Wed Jul 16 18:11:23 2014 CEST using RSA key ID 7621C403\n# gpg: Good signature from \"Example Author <author\@example.com>\"\n\n# tag 'v1.0.1'\n\343\201\223\343\202\223\343\201\253\343\201\241\343\201\257\n\n# gpg: Signature made Wed Jul 16 18:11:23 2014 CEST using RSA key ID 7621C403\n# gpg: Good signature from \"Example Author <author\@example.com>\"\n",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    mergetag => [
      "object fc862ff3b0b4eb337e6ed714031c6cdeaa42ffd9\ntype commit\ntag v1.1.0\ntagger Example Committer <committer\@example.com> 1405527082 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQrAAoJEOX2RRt2IcQDHNEH/18O60/7Q2ALyrgQ0ArhBvUG\nM/El7f84thgfbwbYeDmg65zMrzy5B+8ny8TCSBgza7d2QICu4QTHk/UesiHftaSA\nauQpj57ky3rnZMEwepCiJmYyeVwHerDaNQm7ldqb3yktnj65dfbyHQ8M5IjeWAC6\nz7pH31gInps15hWTnJzlmkqQWPKHVxMQzSkY4oWUMltLi0YoEtgqtwTwH8heKBFQ\neDGHAjEgAxZanBF0yIN+OKWrPgPF6UFjvrtyxeJ8c5R5t/al1JwMi6ULRIjJ9BA0\nzQct7xpSNz8qncNfmiJHHfnwlHBT95nTvsatO+OZPNpvO9vFmr41QsklYsXrOGQ=\n=VnjD\n-----END PGP SIGNATURE-----",
      "object 1f2e387e072680656acac623ea04e1b2b054e8c7\ntype commit\ntag v1.0.1\ntagger Example Committer <committer\@example.com> 1405527082 +0100\n\n\343\201\223\343\202\223\343\201\253\343\201\241\343\201\257\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQrAAoJEOX2RRt2IcQD70AIAI89r83aW3hwj5x4HXx+xj8p\nT/hdAtdkv86j4M3Wi1eJ6BDwmEa0ZwW+Zsxd8ucal7/pprpI68ZkGNoJdgjrJIKO\nD8MkEl9US2ZhM5xtRAjlGqWcVj9KRW09dSHiI7NBhDDrazdZb2sd9HKFrP+RTFIy\n1OzftuOSZfN05pHfKHEwpE96pfQC/EjcY8EL3cJT8MofQbeIGRAJEopcVC4mDHIk\nkW5UtwlYuof31lfq1pePzwcXbuW0Iu9rgEXM5Fi5UMk7YAqSVyhDd1OBAeLID5Xg\nYSizb5DuL6TuK8d3zCQkZohwIzx/a7noLeY9c7c8IqNEJ0GLRC4bJCISZR9h9p8=\n=pEp9\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "32defe32456a053a9c391cdcf9a4292af6d3c80a",
      "fc862ff3b0b4eb337e6ed714031c6cdeaa42ffd9",
      "1f2e387e072680656acac623ea04e1b2b054e8c7"
    ],
    subject => "Merge tags 'v1.1.0' and 'v1.0.1' into mergetags",
    tree => "a319709ffcce3607d752ca412bd1db7f932cce81"
  },
  "4e93b5c9530e543075dc2b2373aa0785acc31a3a" => {
    author => "Example Author <author\@example.com> 1405523506 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    parent => [
      "e2a207202a60cec5968c315a3249fdb4831a5d08"
    ],
    subject => "add the README",
    tree => "8c2bcf77a059f11df2933656ddb437bbfad723ed"
  },
  "6015b6a34038fd16fa8393a066493e6fcc9a174a" => {
    author => "Andr\303\251 <author\@example.com> 1405523484 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    parent => [
      "255a1a6e669ab3b04fd53d26c3ffcdfe16d83a3e"
    ],
    subject => "h\303\251ll\303\262",
    tree => "a319709ffcce3607d752ca412bd1db7f932cce81"
  },
  "6ba823ece3063b52e1d44cdde497332645fb49e0" => {
    author => "Example Author <author\@example.com> 1405523485 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    parent => [],
    subject => "empty tree",
    tree => "4b825dc642cb6eb9a060e54bf8d69288fbee4904"
  },
  "73dbff4c40d38f3d2b7be0476fd0cc40c2d29d15" => {
    author => "Example Author <author\@example.com> 1405523496 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    gpgsig => "-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQrAAoJEOX2RRt2IcQDUpIIAIkOUvX3834rFJcF18rEmfue\nzIFNi3C12S/G6APTg6V2WlwuVtJF6tFc4JScwzgFm4bYrb2JWOaIvAhjNlTnfhxf\nC+UTYcoxxYQKtPdyBNH9dafyrAnxo8FMoVpm/eYbj5rq5ZBlxEIXas8AV0VTK4au\nCzjg73Pib0STVbtF8MqW4KxFfucI770pv9Oj7aZX8WFWzpQZiyGJMiAu/c6Ajeob\nkNtgSvr5OweVKWVdG7EwV4tAtck6tLoJHpOh1CUFORPW3IEjcTPGtAVFDVYiKq/Y\n905mbcbhL0ljoB1iBsQ1xFMZWN2aX75xOhMwQakRGp20UiZuKhd4Fjm2421aMzU=\n=3WvP\n-----END PGP SIGNATURE-----",
    parent => [
      "1f2e387e072680656acac623ea04e1b2b054e8c7"
    ],
    subject => "ol\303\241 (pt)",
    tree => "33a90fc1da2f84bfc394fa886a3d70ae534dc03f"
  },
  "7bc08ae3886d74a575cd92c5f3877e481b45bb07" => {
    author => "Example Author <author\@example.com> 1405523489 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    parent => [
      "32defe32456a053a9c391cdcf9a4292af6d3c80a"
    ],
    subject => "\343\201\223\343\202\223\343\201\253\343\201\241\343\201\257 (ja)",
    tree => "51827db31da3d816058b613f19c971e5c4fa6f16"
  },
  "989960e0d2f4195927a505447b5e641c41373d7f" => {
    author => "Example Author <author\@example.com> 1405523498 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    parent => [
      "73dbff4c40d38f3d2b7be0476fd0cc40c2d29d15"
    ],
    subject => "",
    tree => "524a684865d9b37e0a7236df14ccde01501f063d"
  },
  c9a1ee109ebce2a8ce1ed4dffaec9c691c4915f0 => {
    author => "Example Author <author\@example.com> 1405523503 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    gpgsig => "-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQsAAoJEOX2RRt2IcQDDNwH/1vf113qFEZq04/i6ZN26sTc\ntTLK9n8Y4WbV+tj2MC930SsId1hn75OdFfHE6Lh4ZsMt8sBubCMPaWo1CnCmNcCr\nOWPiLvUj8WI6TC+ZuNCEAzKWVZsyWVn6pnUEQPjy1MOHKpKPFdPQpRi8VGs+dDja\nLR86J1ZuSbqY/4KWAPK9Q0QmYzHna8OlwdSJnY9s5tjyiGr6yDa7pnFd3nBrjbuo\nlDiOadBfEzJCF1jWmPeNPswVyXinPG006ki7zsc/za4ugUyE40Kvl+QGuM/OLJ6+\niOD7q9rror5t1Hr14hSBri9h4kpOP+qW/Ezx7DlnwF3tVB3X3JXsHFgthZW2ex8=\n=UxWl\n-----END PGP SIGNATURE-----",
    mergetag => [
      "object 73dbff4c40d38f3d2b7be0476fd0cc40c2d29d15\ntype commit\ntag v1.0.2\ntagger Example Committer <committer\@example.com> 1405527082 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQrAAoJEOX2RRt2IcQDSgsH/3GGToydJnBf9C3d5gXh8Tfg\nmpobajQ2dbjfZOkQSWXmUbZG0N8GDGZYR0FSXzExJD3whkNCbtnMKPgcryoTOSkI\ntozWoymtu0gHW43LXyHL/t5f3zFbRTLs6be97fJM0On0hK8ZnIKyDx8UvetlRsY7\nFgikiCbnzEzfNasNFprkElGB94btTXCErjhXbJaJ6qlNPfXKS/0qrCVv1WBSBUxR\nFvsUZEb5SH/It1saC3UNAftnPp1eZ4KjRUQC3li3XiGCGX6QWcE61C3A2BKPIApl\nzSyqA4IGz2/jwz+YEFx3DIapMN4u6LC83EC5Hgl+O4GRpjKI1CdgYGQHnwMMUW8=\n=Roel\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "fa59af7668ae3358b1e23a47630fbec5f3f1ef50",
      "73dbff4c40d38f3d2b7be0476fd0cc40c2d29d15"
    ],
    subject => "bom dia",
    tree => "7b8f01341e59251bbf067b1001cdd12f44c36847"
  },
  cb9416d5aae2ffdad123328812079a2302030dad => {
    author => "Example Author <author\@example.com> 1405523506 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    gpgsig => "-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQsAAoJEOX2RRt2IcQDTxcH/2nJwnVN0XH/gEbtObhmf3R8\neOcMlYmNZAFS5Yw7H7oVRK6WGcRVs+dWFGCf9vF62nQxU41zICs5Y9ycjb5/VeJc\nb2+mXYjz6f6y3n3LsRKqQHjNnkCB7KCrxrSaCgjhploPCzZNSzlsJv1uZ/A5hBHt\nUC0qm4MPyjXvN4LW/S9j7X9xiNBnqTuC0scuacDk0sPZD4gf5lh41nSYBhIE/CeO\njtlmwnUdwPjnhAXGnat8GoAeOgvIR28b6ZfgdjJWigw/pJi87Uyk7gzwBkiUwD1Z\n9iQM9uBUQSctTiqg4hGLHRwEk+PUPmaitqySnM/D0d2DElRQYMXTUuuDMZB5AZE=\n=FYmK\n-----END PGP SIGNATURE-----",
    mergetag => [
      "object fc862ff3b0b4eb337e6ed714031c6cdeaa42ffd9\ntype commit\ntag v1.1.0\ntagger Example Committer <committer\@example.com> 1405527082 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQrAAoJEOX2RRt2IcQDHNEH/18O60/7Q2ALyrgQ0ArhBvUG\nM/El7f84thgfbwbYeDmg65zMrzy5B+8ny8TCSBgza7d2QICu4QTHk/UesiHftaSA\nauQpj57ky3rnZMEwepCiJmYyeVwHerDaNQm7ldqb3yktnj65dfbyHQ8M5IjeWAC6\nz7pH31gInps15hWTnJzlmkqQWPKHVxMQzSkY4oWUMltLi0YoEtgqtwTwH8heKBFQ\neDGHAjEgAxZanBF0yIN+OKWrPgPF6UFjvrtyxeJ8c5R5t/al1JwMi6ULRIjJ9BA0\nzQct7xpSNz8qncNfmiJHHfnwlHBT95nTvsatO+OZPNpvO9vFmr41QsklYsXrOGQ=\n=VnjD\n-----END PGP SIGNATURE-----",
      "object 73dbff4c40d38f3d2b7be0476fd0cc40c2d29d15\ntype commit\ntag v1.0.2\ntagger Example Committer <committer\@example.com> 1405527082 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQrAAoJEOX2RRt2IcQDSgsH/3GGToydJnBf9C3d5gXh8Tfg\nmpobajQ2dbjfZOkQSWXmUbZG0N8GDGZYR0FSXzExJD3whkNCbtnMKPgcryoTOSkI\ntozWoymtu0gHW43LXyHL/t5f3zFbRTLs6be97fJM0On0hK8ZnIKyDx8UvetlRsY7\nFgikiCbnzEzfNasNFprkElGB94btTXCErjhXbJaJ6qlNPfXKS/0qrCVv1WBSBUxR\nFvsUZEb5SH/It1saC3UNAftnPp1eZ4KjRUQC3li3XiGCGX6QWcE61C3A2BKPIApl\nzSyqA4IGz2/jwz+YEFx3DIapMN4u6LC83EC5Hgl+O4GRpjKI1CdgYGQHnwMMUW8=\n=Roel\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "6ba823ece3063b52e1d44cdde497332645fb49e0",
      "fc862ff3b0b4eb337e6ed714031c6cdeaa42ffd9",
      "73dbff4c40d38f3d2b7be0476fd0cc40c2d29d15"
    ],
    subject => "buon giorno (it)",
    tree => "4b825dc642cb6eb9a060e54bf8d69288fbee4904"
  },
  e2a207202a60cec5968c315a3249fdb4831a5d08 => {
    author => "Example Author <author\@example.com> 1405523504 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    gpgsig => "-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQsAAoJEOX2RRt2IcQDGfsH/jmgIgir/dqh6GnxqoHQxVCG\nWhQNAVv3fvods/nKX6mV8ZMh6omdFES9m7lWiT2ZKLfYzgyJwxEHSthGTK11gdRa\ngXmJHzdqul+/wjMpcL1LpR0vp3f73ylPsA2MsI0pLFj+wfxgr03VTWqjsxPMt3Z/\nqTvI3BA5B4moV9UDiQsjcKKxIMyRFxSzTX1RkOtkMedzXu/MBWhLJMJlNqWiiSRJ\nkC/J6RUHCKwHJMl/czbtfw9hFin2A6nPDqUXSlicQaeVN3M6Hop7p5B7FRyaG3M6\nC+NMmPofPN4V1DH3XArulyuc1GpfO55PpBzCPzamoRG5dCIiP2i/4eZOPcIqIMw=\n=UDPB\n-----END PGP SIGNATURE-----",
    mergetag => [
      "object 989960e0d2f4195927a505447b5e641c41373d7f\ntype commit\ntag v1.0.3\ntagger Example Committer <committer\@example.com> 1405527082 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQrAAoJEOX2RRt2IcQDwBsH/idcHUPXJ5K23FvyevuV+LcI\nRWcD7RyhQX5r8aYWfVDiu4VLW9IJuEV2wu/5yjI6x3hRBIry8+OR98rQ/ZXOXRP4\nJCVTogIzHv1wfdJzY3N8TyLQgBUyeqWOi+9RxkeLVYNLclEbQrccljfNepp0aLep\novt9MnK6iLMqeoOht2Ys+JCETB7x3qmahAhn4T0H8h2IiCKRXZxSzsVPrGEikpxx\nvQdnGiYK0A8wtslIR8Co+b+oKuPsRyiHHnehUikM1/pCTDS/53m2N4k/VFpxarXB\nJ+1NlhPJJsLCfahA93hjdKh/WR86+u/ODZix0rSC2bFTxRNf7hfiwFH/23NhSrI=\n=dfpU\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "c9a1ee109ebce2a8ce1ed4dffaec9c691c4915f0",
      "989960e0d2f4195927a505447b5e641c41373d7f"
    ],
    subject => "buen d\303\255a (es)",
    tree => "7b8f01341e59251bbf067b1001cdd12f44c36847"
  },
  f2da33588f3c5678fd1d6700b0b7a3b500e285a6 => {
    author => "Example Author <author\@example.com> 1405523490 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    gpgsig => "-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQrAAoJEOX2RRt2IcQDEuYH/01zbzM4PEOY5EnDkKGc3SjE\niwJi0BmNTeZ7gISm1leMS1alXBeqN/Ex91xW4O0sfDx1TpIPT4T1fY1rMiAEyNZu\nZJOF3zLtwB99b00XELButxkag6y89bPkLYOzHKku6t5FLldUNqMgRW4esrcuh4Fq\n0uPOySLF5ex8TcyRgIDILjyLf94mlaabVMtLWNxSeFkCgv10PjinFCxprEva+q/8\nynbJ7aRUYp5Tvg9b6MAxjQ//+C/1+IHzriXFZb1e0BdR6DfVO6noALwJhHMm8lgm\nPXxKu8RcIR89vpeKqsmqDISREWg5ia/lQTIe+eeuOyQvaqzpAST0LK9V2m44jcU=\n=VTqL\n-----END PGP SIGNATURE-----",
    parent => [
      "7bc08ae3886d74a575cd92c5f3877e481b45bb07"
    ],
    subject => "hej (da)",
    tree => "7b8f01341e59251bbf067b1001cdd12f44c36847"
  },
  f6812d818e65423551c0eb7ac899dbea5311eb56 => {
    author => "Andr\303\251 <author\@example.com> 1405523492 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    parent => [
      "0b2d9d33df9eebbbfea07fab53019f63571183c6"
    ],
    subject => "hall\303\263 (is)",
    tree => "1840015fc84bf133760c966eed4c1b4047ea657a"
  },
  fa59af7668ae3358b1e23a47630fbec5f3f1ef50 => {
    author => "Example Author <author\@example.com> 1405523502 +0100",
    body => "",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    mergetag => [
      "object 1f2e387e072680656acac623ea04e1b2b054e8c7\ntype commit\ntag v1.0.1\ntagger Example Committer <committer\@example.com> 1405527082 +0100\n\n\303\243\302\201\302\223\303\243\302\202\302\223\303\243\302\201\302\253\303\243\302\201\302\241\303\243\302\201\302\257\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQrAAoJEOX2RRt2IcQD70AIAI89r83aW3hwj5x4HXx+xj8p\nT/hdAtdkv86j4M3Wi1eJ6BDwmEa0ZwW+Zsxd8ucal7/pprpI68ZkGNoJdgjrJIKO\nD8MkEl9US2ZhM5xtRAjlGqWcVj9KRW09dSHiI7NBhDDrazdZb2sd9HKFrP+RTFIy\n1OzftuOSZfN05pHfKHEwpE96pfQC/EjcY8EL3cJT8MofQbeIGRAJEopcVC4mDHIk\nkW5UtwlYuof31lfq1pePzwcXbuW0Iu9rgEXM5Fi5UMk7YAqSVyhDd1OBAeLID5Xg\nYSizb5DuL6TuK8d3zCQkZohwIzx/a7noLeY9c7c8IqNEJ0GLRC4bJCISZR9h9p8=\n=pEp9\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "fc862ff3b0b4eb337e6ed714031c6cdeaa42ffd9",
      "1f2e387e072680656acac623ea04e1b2b054e8c7"
    ],
    subject => "dobr\303\275 den (cs)",
    tree => "7b8f01341e59251bbf067b1001cdd12f44c36847"
  },
  fc862ff3b0b4eb337e6ed714031c6cdeaa42ffd9 => {
    author => "Example Author <author\@example.com> 1405523500 +0100",
    body => "signed tag\n\n# gpg: Signature made Wed Jul 16 18:11:23 2014 CEST using RSA key ID 7621C403\n# gpg: Good signature from \"Example Author <author\@example.com>\"\n",
    committer => "Example Committer <committer\@example.com> 1405527082 +0100",
    extra => "",
    mergetag => [
      "object f6812d818e65423551c0eb7ac899dbea5311eb56\ntype commit\ntag v1.0.0\ntagger Example Committer <committer\@example.com> 1405527082 +0100\n\nsigned tag\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.12 (GNU/Linux)\n\niQEcBAABAgAGBQJTxqQrAAoJEOX2RRt2IcQD1hwH/3JQsd1XnB4p7LBlR6YwhJzd\n68cvB7pgPMURk9a6LpxvOIhwAwg6BQtzPvMOL4KPrUuymAsQAjjtH6Qfc99O+V+F\nOrGPn5EL7LerUT0NUQjeHRfgX0p73QYQTEf3Ua8wNkiVyxD7paAgIQ19SzRIRk6B\ngGf4Tjn9wxDddRC0AiBwavocsMYiHW1r1LyC27KLeP46xTZGM/oqOs4h5XPqfrtT\npGvLrcE1WqwlhK3vAS6mDObzTfrMWiMR7FDMPPBM0m9yiCW4aBZ0gguUZOi1hq0x\nItzZcHRQ7ougAlfuaj/J9K5zaaaziF71ptb+3OlHnidmGSSTYrHtn/A7ZOSh2MI=\n=+KXN\n-----END PGP SIGNATURE-----"
    ],
    parent => [
      "f2da33588f3c5678fd1d6700b0b7a3b500e285a6",
      "f6812d818e65423551c0eb7ac899dbea5311eb56"
    ],
    subject => "Merge tag 'v1.0.0'",
    tree => "7b8f01341e59251bbf067b1001cdd12f44c36847"
  }
);
