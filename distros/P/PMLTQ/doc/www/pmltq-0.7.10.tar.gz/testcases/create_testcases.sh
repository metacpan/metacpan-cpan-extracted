#!/bin/bash

./bin/query2pml.pl -f "./queries/*.tq" -o queries_testcases.pml