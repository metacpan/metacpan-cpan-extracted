package WWW::WTF::HTTPResource::Types::Plaintext;

use common::sense;

use Moose::Role;

1;
