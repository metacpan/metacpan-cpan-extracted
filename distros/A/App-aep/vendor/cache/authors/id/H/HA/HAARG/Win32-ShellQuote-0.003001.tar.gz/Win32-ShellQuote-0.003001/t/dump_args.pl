use strict;
use warnings;
use File::Basename qw(dirname);
use TestUtil;

print dd(\@ARGV);

1;
