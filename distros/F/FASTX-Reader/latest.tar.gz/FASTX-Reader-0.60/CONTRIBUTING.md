## Contributing to FASTX::Reader

Feel free to contact the author to collaborate, or refer to the github page:

https://github.com/telatin/FASTQ-Parser
