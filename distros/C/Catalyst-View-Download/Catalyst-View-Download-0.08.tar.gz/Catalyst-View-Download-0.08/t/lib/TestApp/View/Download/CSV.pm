package TestApp::View::Download::CSV;

use FindBin;
use lib "$FindBin::Bin/../../../../../lib";
use lib "$FindBin::Bin/../../../../lib";
use base 'Catalyst::View::Download::CSV';

1;
