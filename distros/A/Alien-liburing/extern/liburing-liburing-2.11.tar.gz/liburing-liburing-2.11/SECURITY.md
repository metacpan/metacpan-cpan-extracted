# Security Policy

## Reporting a Vulnerability

Please report any security issue to axboe@kernel.dk where the issue will be triaged appropriately.
Thank you in advance for helping to keep liburing secure.
