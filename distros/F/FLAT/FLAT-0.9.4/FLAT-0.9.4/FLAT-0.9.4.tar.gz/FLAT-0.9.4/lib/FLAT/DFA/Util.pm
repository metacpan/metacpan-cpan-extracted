package FLAT::DFA::Util;

use strict;
use warnings;

1;
