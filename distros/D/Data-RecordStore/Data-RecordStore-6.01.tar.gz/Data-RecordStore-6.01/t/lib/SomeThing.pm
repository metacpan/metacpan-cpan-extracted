package SomeThing;

use Data::ObjectStore;
use base 'Data::ObjectStore::Container';

1;
