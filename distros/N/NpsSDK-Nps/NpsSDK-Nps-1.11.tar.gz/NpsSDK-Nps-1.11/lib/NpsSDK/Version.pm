package NpsSDK::Version;

use warnings; 
use strict;

our $VERSION = '1.11';

1;
