For your convenience libmemcached contains a copy of protocol_binary.h so that
you may compile libmemcached without having a memcached server with support
for the binary protocol installed on your computer. Please do not modify this
fine, but replace it with a fresh copy from a new distribution if they are 
out of sync.

Trond Norbye
