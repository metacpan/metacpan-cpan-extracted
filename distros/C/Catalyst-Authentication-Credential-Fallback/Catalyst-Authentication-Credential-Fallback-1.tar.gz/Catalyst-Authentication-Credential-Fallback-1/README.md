Catalyst-Authentication-Credential-Fallback
===========================================

Development of Catalyst::Authentication::Credential::Fallback
