perl ./perlfix.pl
