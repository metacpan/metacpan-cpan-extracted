use strict;
use warnings;
package Acme::NameChangeTest;

=head1 NAME

Acme::NameChangeTest - module for testing module name changes in PAUSE

1;
