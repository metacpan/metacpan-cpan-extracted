
=head1 NAME

Foo::Bar - Do funny things with InlineX::XS

=cut

package Foo::Bar;
use 5.006;
use strict;
use warnings;
our $VERSION = '0.01';
BEGIN {$VERSION = '0.01'}

use InlineX::XS <<'HERE';
int
fac (int x)
{
    if (x <= 0) return(1);
    return(x*fac(x-1));
}
HERE

sub fac_series {
    # stupid idea :)
    return map {fac($_)} 0..(shift(@_)||1);
}

sub fac_series_squared {
    return map {square($_)} fac_series(@_);
}

use InlineX::XS <<'HERE';
double
square (double x)
{
    return x*x;
}
HERE

use InlineX::XS 'END';


