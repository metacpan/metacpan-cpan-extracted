package VTest::VMod6;

our $VERSION = 6.0;

1;
