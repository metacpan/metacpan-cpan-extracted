package My::Dist;

$VERSION = '0.70';

=head1 NAME

My::Dist

=head1 SYNOPSYS

    use My::Dist;

=head1 DESCRIPTION

The purpose here is to see what happens when updating the database and adding a
new distribution.

The trick here, when compared to version 0.60, is that the distribution 
to which the note had originally been addes is long gone, so the system 
will have to choose its own reference paragraph.

Let's put the original paragraph (with a minor modification) back for fun:

This is my module. There are many like it, but this one is mine.

=cut

1;

