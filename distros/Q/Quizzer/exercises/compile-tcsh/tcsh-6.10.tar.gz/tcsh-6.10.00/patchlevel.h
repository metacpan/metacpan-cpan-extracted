/* $Header: /src/pub/tcsh/patchlevel.h,v 3.126 2000/11/19 20:50:43 christos Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 10
#define PATCHLEVEL 0
#define DATE "2000-11-19"

#endif /* _h_patchlevel */
