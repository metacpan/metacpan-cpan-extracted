package App::mokupona;

our $VERSION = 2.02;

=head1 NAME

App::mokupona - a feed aggregator for Gopher, Gemini, RSS and Atom

=head1 DESCRIPTION

This is a stub module, see F<script/moku-pona> for details of the app.

=head1 AUTHOR

Alex Schroeder

=head1 LICENSE

GNU Affero General Public License

=cut

1;
