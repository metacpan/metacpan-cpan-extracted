package XS::libpanda;
use XS::Loader;

our $VERSION = '1.5.9';

XS::Loader::load_noboot();

1;
