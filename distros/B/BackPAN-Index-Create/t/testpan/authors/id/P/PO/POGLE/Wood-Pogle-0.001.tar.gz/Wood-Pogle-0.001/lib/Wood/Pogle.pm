use strict;
use warnings;
package Wood::Pogle;

# ABSTRACT: Pogle's Wood

1;
