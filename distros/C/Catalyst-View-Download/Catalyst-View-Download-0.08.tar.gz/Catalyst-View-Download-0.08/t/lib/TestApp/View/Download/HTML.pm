package TestApp::View::Download::HTML;

use FindBin;
use lib "$FindBin::Bin/../../../../../lib";
use lib "$FindBin::Bin/../../../../lib";
use base 'Catalyst::View::Download::HTML';

1;
