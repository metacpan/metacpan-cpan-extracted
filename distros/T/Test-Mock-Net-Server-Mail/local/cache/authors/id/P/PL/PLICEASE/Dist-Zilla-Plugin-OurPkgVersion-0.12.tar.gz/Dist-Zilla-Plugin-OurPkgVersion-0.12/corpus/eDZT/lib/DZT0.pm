use strict;
use warnings;
package DZT0;
# VERSION
# ABSTRACT: my abstract
1;
