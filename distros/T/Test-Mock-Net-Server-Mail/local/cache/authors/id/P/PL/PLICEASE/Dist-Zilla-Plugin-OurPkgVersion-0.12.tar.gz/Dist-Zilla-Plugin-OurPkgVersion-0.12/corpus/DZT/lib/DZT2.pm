use strict;
use warnings;
package DZT2;
1;
