# MARC-Indexer
Extract data from MARC records for indexing purposes
