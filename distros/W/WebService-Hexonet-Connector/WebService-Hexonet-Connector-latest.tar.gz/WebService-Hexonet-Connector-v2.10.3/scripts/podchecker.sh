#!/bin/bash
find ./lib -name "*.pm*" -exec podchecker {} \;
