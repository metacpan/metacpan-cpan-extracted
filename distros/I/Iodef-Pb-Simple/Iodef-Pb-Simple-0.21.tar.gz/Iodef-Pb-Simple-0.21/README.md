[![Build Status](https://travis-ci.org/csirtgadgets/iodef-pb-simple-perl.png?branch=master)](https://travis-ci.org/csirtgadgets/iodef-pb-simple-perl)

Iodef-Pb-Simple
==

INSTALLATION
==

To install this module type the following:

   perl Makefile.PL
   make
   make test
   make install

COPYRIGHT AND LICENCE
==
Copyright (C) 2013 by Wes Young <wesyoung.me>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.10.1 or,
at your option, any later version of Perl 5 you may have available.
