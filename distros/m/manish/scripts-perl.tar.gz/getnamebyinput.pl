#!/usr/bin/perl -w
print "please enter your name here --- = ";

chomp($name=<STDIN>);
print "hi friend your name is $name \n";
