package Form::Processor::I18N::en_us;
use strict;
use warnings;
use base 'Form::Processor::I18N';

# Auto define lexicon
our %Lexicon = (
    '_AUTO' => 1,
  );

1;




