package Simpel::Banget;

our $VERSION = '0.001';

1;

=head1 NAME

Simpel::Banget - A very modest module

=cut
