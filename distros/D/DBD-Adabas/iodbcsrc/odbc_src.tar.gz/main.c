#include	<iodbc.h>

/* entry function used to build a share library on AIX  */
int	__start()
{
	return 0;
}
