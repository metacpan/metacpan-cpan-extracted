#!perl
use strict;
use warnings;
use Carp::REPL qw/warn noprofile/;

my $a = 4;
my $b;

print $a + $b;

