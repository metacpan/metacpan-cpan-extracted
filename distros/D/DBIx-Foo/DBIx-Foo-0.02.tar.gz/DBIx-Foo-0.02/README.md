DBIx-Foo
========

Simple Database Wrapper and Helper Functions.  Easy DB integration without the need for an ORM.

***** THIS IS WORK IN PROGRESS *****

INSTALLATION

To install this module type the following:

    perl Makefile.PL
    make
    make test
    make install

Or use CPAN / cpanm / carton to automate the process.

PREREQUISITES

    DBI
    Exporter
	Log::Any
