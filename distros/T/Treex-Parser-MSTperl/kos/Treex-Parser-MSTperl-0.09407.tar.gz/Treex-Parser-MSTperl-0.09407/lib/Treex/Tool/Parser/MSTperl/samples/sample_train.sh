#!/bin/bash
./train_tsv.pl sample_train.tsv sample.model sample.config 1
