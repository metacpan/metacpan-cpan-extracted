package Sederhana;

our $VERSION = '2.0.2';

1;

=head1 NAME

Sederhana - A simple yet useful module

=cut
