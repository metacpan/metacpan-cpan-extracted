package WWW::WTF::HTTPResource::Plaintext;

use common::sense;

use Moose::Role;

1;
