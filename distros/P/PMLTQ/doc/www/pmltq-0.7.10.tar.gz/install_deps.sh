#!/bin/sh

cpan UNIVERSAL::DOES Net::HTTPServer HTTP::Request HTML::TokeParser HTTP::Request::AsCGI \
    Sys::SigAction Parse::RecDescent XML::LibXML MIME::Types IO::Scalar HTTP::Server::Simple::CGI \
    JSON YAML

cpan DBD::Pg
cpan DBD::Oracle # for postgres and oracle
