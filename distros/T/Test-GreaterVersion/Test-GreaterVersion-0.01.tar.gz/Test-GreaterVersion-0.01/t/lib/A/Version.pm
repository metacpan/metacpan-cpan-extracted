package A::Version;

our $VERSION=1.234;

return 1;