use strict;
use warnings;

sub func1 {
  return 1;
}

1;
