#include <stdio.h>
#include "libdontpanic.h"

int
main(int argc, char *argv[])
{
  printf("the answer to life the universe and everything is %d\n", answer());
  return 0;
}
