package Game::Asset::TestPack;
use strict;
use warnings;
use Moose;
use namespace::autoclean;


no Moose;
__PACKAGE__->meta->make_immutable;
__PACKAGE__;
__END__

