package WWW::WTF::UserAgent;

use common::sense;

use v5.12;

use Moose;

sub get { ... }

sub recurse { ... }

__PACKAGE__->meta->make_immutable;

1;
