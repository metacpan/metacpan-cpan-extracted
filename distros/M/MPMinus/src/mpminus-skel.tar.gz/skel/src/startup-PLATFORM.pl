#!/usr/bin/perl -w
# Taken from http://perl.apache.org/docs/2.0/user/handlers/server.html#Startup_File

die "GATEWAY_INTERFACE not Perl!" if !$ENV{MOD_PERL};

# preload all mp2 modules
# use ModPerl::MethodLookup;
# ModPerl::MethodLookup::preload_all_modules();

# SECTION INIT: USE ModPerl modules 
use ModPerl::Util (); #for CORE::GLOBAL::exit

use Apache2::Filter ();
use Apache2::FilterRec ();

use Apache2::Const qw(-compile :common);
use Apache2::RequestRec ();
use Apache2::RequestIO ();
use Apache2::RequestUtil ();
use Apache2::ServerRec ();
use Apache2::ServerUtil ();
use Apache2::Connection ();
use Apache2::Log ();

use APR::Const qw(-compile :common);
use APR::Table ();
use APR::Bucket ();
use APR::Brigade ();

use ModPerl::Registry ();

# SECTION INIT: USE Other modules
use Apache2::Status;
use Apache::DBI;

# Precompilation CGI.pm
use CGI qw(-compile :all);
use TemplateM;

1;
