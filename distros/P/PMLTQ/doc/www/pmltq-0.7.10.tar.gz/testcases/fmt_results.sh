#!/bin/sh
grep -E '\[|real' "$1" |perl -pe 'chomp if /\[/; s/^real//'
