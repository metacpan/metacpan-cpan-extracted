#include "string_test.h"
TEST_CASE("basic_string<wchar_t>", "[string][string_wchar]") { test::test_string<wchar_t>::run(); }
