use strict;
use warnings;
package DZT3;
# This is a comment
1;
