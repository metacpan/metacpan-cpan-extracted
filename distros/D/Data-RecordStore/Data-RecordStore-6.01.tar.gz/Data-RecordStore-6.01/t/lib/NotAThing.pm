package NotAThing;

1;
