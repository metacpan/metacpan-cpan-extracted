package bin4tsv::ja ;
our $VERSION = 0.01 ;

=encoding utf8

=head1 NAME
 
bin4tsv::ja

=head1 SYNOPSIS

ここには日本語の解説を載せる予定。

=head1 DESCRIPTION
 
=head1 SEE ALSO

=cut

