#!perl
use strict;
use warnings;

our $pi;

my %surname_of =
(
    Sean => 'Bean',
    Christopher => 'Walken',
);

sub call_me_when_you_have_pie
{
    return eval '$pi * 2';
}

die another day;
package day;
sub another {'and on your left we have a Bond fan with too much free time'}
