Author: Jerzy Wachowiak; Version: 1.0; Last update: 2005-05-20.

==========================================
   Hints for straw usage
==========================================

@ straw

USAGE:
./xdstraw -h host -p port [-d directory]

DESCRIPTION:
straw opens on start an INET socket connection to the host and port specified 
in the argument line and starts a very simple shell. Shell input is interpreted 
as a file name in the straw current working directory or directory specyfied
in the argument line at start. The content of the file is read and transmitted
to the host and the answer is displayed. As straw is used mostly with XML 
protocols, XML is coloured but no pretty printing is used. To stop straw use 
CTR+C.


@ Naming convention for jabber files

The files are generated according to the following naming convention:
 c - open XML stream (connection) to the jabber server;
 a - plain authentication request;
 p - presence on;
 s - selftest (message to itself);
 n - message of type normal;
 g - good message;
 b - bad message;
 e - some jabber internal error. 
Meaning of good and bad message depends on the role of the agent. Archivist
filenames, which are sent as response to Senders, are numbered 1, 2, 3, ... 
according the alias naming convention in the Archivit's database (sender1, 
sender2, sender3, ...)


@ Typical test session

Read the docs to understand, what is going on inside xDash. Check execution
rights for the straw script. If using example provided in the CPAN module, open 
3 terminal sessions, each one for Sender, Receiver and Archivist. Typical test 
session consists of the following steps:
[1] ./straw
[2] c -> waiting for jabber server response
[3] a -> waiting for jabber server response
[4] p -> waiting for jabber server response
[5] s -> waiting for jabber server response
[6] n -> waiting for jabber server response
[7] g -> waiting for response of another agent
[8] b -> waiting for response of another agent
[9] e -> waiting for jabber server response
[10] CRT+C


@ Sea also

[1] Book "Programming Jabber" by DJ Adams, ISBN: 0-596-00202-5;
[2] Jabber protocol description on www.jabber.org.
