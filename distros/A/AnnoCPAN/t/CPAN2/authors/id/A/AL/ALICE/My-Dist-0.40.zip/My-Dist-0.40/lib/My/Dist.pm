package My::Dist;

$VERSION = '0.40';

=head1 NAME

My::Dist

=head1 SYNOPSYS

    use My::Dist;

=head1 DESCRIPTION

The purpose here is to test a zip dist.

This is a dist. There are many like it, 
but this one is mine.

=cut

1;

