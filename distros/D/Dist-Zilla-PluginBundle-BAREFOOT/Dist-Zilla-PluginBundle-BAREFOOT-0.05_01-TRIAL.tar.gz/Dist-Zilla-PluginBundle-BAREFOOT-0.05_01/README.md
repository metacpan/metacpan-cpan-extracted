Dist::Zilla::PluginBundle::BAREFOOT
===================================

This is a plugin bundle for [Dist::Zilla](http://dzil.org/).  It's mostly for me, but feel free to use it if you like.

Installing
----------

Install this from CPAN:

	cpanm -n Dist::Zilla::PluginBundle::BAREFOOT

Contributing
------------

Start an issue on GitHub and we'll chat.

Copying
-------

Artistic License.  See the `LICENSE` file for full details.
