package {{$dist->name =~ s{-}{::}gr}}::AdjacencyGraph;
use strict;
use warnings;
use Data::Password::zxcvbn::AdjacencyGraph::Common;
use Data::Password::zxcvbn::AdjacencyGraph::{{(split /-/,$dist->name)[-1]}};
# VERSION
# ABSTRACT: adjacency graphs for common {{(split /-/,$dist->name)[-1]}} keyboards

=head1 DESCRIPTION

This merges the common graphs from the C<Data::Password::zxcvbn>
distribution, and {{(split /-/,$dist->name)[-1]}} keyboards.

=cut

our %graphs = (
    %Data::Password::zxcvbn::AdjacencyGraph::Common::graphs,
    %Data::Password::zxcvbn::AdjacencyGraph::{{(split /-/,$dist->name)[-1]}}::graphs,
);

1;
