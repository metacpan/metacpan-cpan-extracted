#include "string_test.h"
TEST_CASE("basic_string<char16_t>", "[string][string_char16]") { test::test_string<char16_t>::run(); }
