package Data::RecordStore::New;

use strict;

sub init_store {
    
}

sub open_store {
    
}

sub lock {

}

sub unlock {

}

sub stow {

}

sub fetch {

}

sub delete_record {

}

sub has_id {

}

sub next_id {

}

sub empty {

}

sub size {

}

sub entry_count {

}

sub record_count {

}


"Meet the new boss Same as the old boss - The Who";
