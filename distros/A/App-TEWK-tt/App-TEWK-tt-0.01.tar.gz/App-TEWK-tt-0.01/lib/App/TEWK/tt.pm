package App::TEWK::tt;

our $VERSION = 0.01;

=head1 NAME

App::tt - an app that runs CXXTests

=head1 DESCRIPTION

This is a stub module, see F<script/tt> for details of the app.

=head1 AUTHOR

Kevin Tew

=head1 LICENSE

FreeBSD

=cut

1;
