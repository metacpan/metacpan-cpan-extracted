package Foo;

use strict;
use warnings;

our $VERSION = '1.0.0';

1;
