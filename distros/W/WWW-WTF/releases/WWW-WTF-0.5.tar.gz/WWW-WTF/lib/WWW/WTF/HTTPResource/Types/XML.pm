package WWW::WTF::HTTPResource::Types::XML;

use common::sense;

use Moose::Role;

1;
