#include <stdio.h>
#include <sqlite3.h>

int main()
{
   printf("Hello, World!");
   return 0;
}
