package NpsSDK::Version;

use warnings; 
use strict;

our $VERSION = '1.10';

1;
