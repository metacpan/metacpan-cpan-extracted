package WWW::WTF::Helpers::Google::PageSpeed;

use common::sense;

use Moose;

__PACKAGE__->meta->make_immutable;

1;
