package WWW::WTF::HTTPResource::SVG;

use common::sense;

use Moose::Role;

1;
