This spec test suite is written in YAML so that other Sah implementations can
easily read it.

Additional, implementation-specific tests can be found in the respective
implementations' distributions.
