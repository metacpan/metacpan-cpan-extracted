package VTest::VMod6;

our $VERSION = 7.0;

1;
