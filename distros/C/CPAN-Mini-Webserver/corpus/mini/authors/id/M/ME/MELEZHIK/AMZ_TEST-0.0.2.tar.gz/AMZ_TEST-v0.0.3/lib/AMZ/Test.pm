=head1 SYNOPIS

 тестируем документацию

=cut

package AMZ::Test;

$VERSION = 0.0.3;
