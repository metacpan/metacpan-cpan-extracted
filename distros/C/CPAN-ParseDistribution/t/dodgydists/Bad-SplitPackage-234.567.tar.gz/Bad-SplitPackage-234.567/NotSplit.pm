package NotSplit;

$VERSION = 234.567;
