# Perl module Graphviz::Diagram::ClassDiagram
