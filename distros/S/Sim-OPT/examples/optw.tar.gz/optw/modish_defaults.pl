@defaults = ( [  2, 2 ], 1, 1, 2, 0.01, 0.99 );



### The above line means: ( [ resolution_x, resolution_y ], $dirvectorsnum, $bounceambnum, $bouncemaxnum, $distgrid, $threshold )

### resolution_x, resolution_y are the gridding values

### The value "$dirvectorsnum" controls the numbers of direction vectors that are used for 
### computing the irradiances at each point of each grid over the surfaces. The values that currently
### can be chosen are 1, 5 and 9. When the points are more than 1, they are evenly distributed 
### on a hemisphere following a geodetic pattern.

### $bounceambnum are the number of the bounces of the diffuse light which are taken into account

# $bouncemaxnum are the number of the bounces of the direct light which are taken into account

# $distgrid is the distance of the grid in meter out of the surfaces which are tamen into account

# $threshold is the threshold under which the changes of shading value are not taken into account. 
# A value of "1" means that if the new shading value is increased instead of decreased in place of the old one,
# the change is not executed.

$computype = "linear";
# TYPES OF CALCULATIONS FOR CALCULATING THE IRRADIANCE FACTORS.
# (SEE SUBROUTINE "compareirrs".)
# OPTIONS: "linear", "quadratic", "root".
# THESE OPTIONS ARE ON THE WAY TO BE DISCARDED AND BECOME OBSOLETE. ONLY "linear will remain".
# WHEN UNSPECIFIED, THE DEFAULT IS "linear".

@calcprocedures = ( "complete", "besides", "diluted", "extra" );
# The options are the following:
# "simplified", "incomplete", "basic", "main", "alternative", "complete", "spreaddiff", "diluted", "quadratic__", "sqroot__", "halved__", 
# "conflated", "conflated__", "extra", "besides", "halved", "halved250", "halved125", "halved375".
# "main", "alternative", "complete" and "spreaddiff" can be combined with the other options. 
# The others can't. "basic" also can be combined with the others: it can be used in place of "alternative".
# "spreaddiff"c CAN'T BE USED ALONE.
# THE "incomplete" OPTION IS UNSATISFACTORY AND ON THE WAY TO BECOME OBSOLETE.
# MORE THAN ONE OPTION MAY CO-EXIST.
# WITH THE "complete", "alternative" and "main" option, both $bounceambnum and $bouncemaxnum must be assigned a value higher than 0.
# WHEN NO @calcprocedures VALUE IS PRESENT, THE PROGRAM DEFAULTS TO "simplified".
# The main alternatives are: "complete", "besides"; and complete besides diluted extra.
# "besides" means that the specular reflection of the reflectors is also specified in the Radiance database.
# "extra" means that the specular reflection of all materials is specifies in the database.
# Both, can be used with $computype = "linear" or "root".
# 

%specularratios = ( reflector => 0, roughnval => 0.00, specval => 0.10, roughnroughval => 0.00, specroughval => 0.00 );
#%specularratios = ( totaldirect => 1 );
#%specularratios = ( reflector => 1 );
# THE VALUE OF EACH OF THESE KEY-VALUE PAIRS CONSTITUTES THE PROPORTION OF THE SPECULAR REFLECTIVITY
# IF THE DIFFUSE REFLECTIVITY IS 1 FOR A MATERIAL ATTRIBUTED TO AN OBSTRUCTION. 
# THE KEY OF THE VALUE IS CONSTITUTED BY THE NAME OF THAT MATERIAL.
# IF %specularratios IS UNSPECIFIED, THE VALUE OF THE RATIO FOR EACH MATERIAL OF EACH OBSTRUCTION
# DEFAULTS TO 1.
# If $calcprocedure IS "basic", HOWEVER, THE VALUE OF %specularratios HAVING "totaldirect" AS KEY
# CONSTITUTES THE PROPORTION OF THE TOTAL DIRECT RADIATION IF THE TOTAL DIFFUSE RADIATION IS 1.
# EXAMPLE: %specularratios = ( totaldirect => 1 );
# (SEE SUBROUTINE "pursue").
# IF IN @calcprocedures "besides" is present, in %specularratios a roughness value 
# between 0 and 1 must be spefied as "roughnval" . the roughness value of reflectors.
# "roughnroughval" is the roughness value of the non-reflectors. 
# "specval" is the ratio of direct to diffuse reflectivity of reflectors.
# "specroughval" is the ratio of direct to diffuse reflectivity of non-reflectors.

%skycondition = ( 1=> "clear", 2=> "clear", 3=> "clear", 4=> "clear", 5=> "clear", 6=> "clear", 7=> "clear", 8=> "clear", 
	9=> "clear", 10=> "clear", 11=> "clear", 12=> "clear" );
# PREVAILING CONDITION OF THE SKY FOR EACH MONTH, EXPRESSED WITH ITS NUMBER.
# THE OPTIONS ARE: "clear", "cloudy" and "overcast".
# IF NO VALUE IS SPECIFIED, THE DEFAULT IS "clear".





