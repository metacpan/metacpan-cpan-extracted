use strict;
use warnings;
package DZT1;
BEGIN {
	# VERSION
}
# ABSTRACT: my abstract
1;
