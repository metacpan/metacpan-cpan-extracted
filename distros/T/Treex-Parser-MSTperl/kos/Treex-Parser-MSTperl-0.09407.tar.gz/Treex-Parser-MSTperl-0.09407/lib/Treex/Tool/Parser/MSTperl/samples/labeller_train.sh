#!/bin/bash
./train_labeller_tsv.pl sample_train.tsv sample.Lmodel sample.config 0 $@
