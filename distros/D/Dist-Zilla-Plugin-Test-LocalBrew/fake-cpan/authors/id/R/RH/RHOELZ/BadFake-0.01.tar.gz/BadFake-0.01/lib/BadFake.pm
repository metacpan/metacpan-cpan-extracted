package BadFake;

use strict;
use warnings;

1;
