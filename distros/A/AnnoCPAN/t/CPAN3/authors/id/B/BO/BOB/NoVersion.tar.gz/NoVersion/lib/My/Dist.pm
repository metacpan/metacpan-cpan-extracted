package My::Dist;

$VERSION = '0.50';

=head1 NAME

My::Dist

=head1 SYNOPSYS

    use My::Dist;

=head1 DESCRIPTION

The purpose here is to see what happens with distributions with
no version.

=cut

1;

