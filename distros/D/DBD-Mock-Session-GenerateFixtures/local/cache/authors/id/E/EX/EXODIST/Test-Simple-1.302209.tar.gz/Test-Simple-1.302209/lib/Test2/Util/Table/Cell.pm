package Test2::Util::Table::Cell;
use strict;
use warnings;

our $VERSION = '1.302209';

use base 'Term::Table::Cell';

1;
