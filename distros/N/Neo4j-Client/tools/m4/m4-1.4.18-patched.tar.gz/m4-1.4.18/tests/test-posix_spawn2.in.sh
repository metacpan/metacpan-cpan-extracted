#!/bin/sh
read line
test "$line" = "Halle Potta"
