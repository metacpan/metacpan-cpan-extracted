#include "string_test.h"
TEST_CASE("basic_string<char32_t>", "[string][string_char32]") { test::test_string<char32_t>::run(); }
