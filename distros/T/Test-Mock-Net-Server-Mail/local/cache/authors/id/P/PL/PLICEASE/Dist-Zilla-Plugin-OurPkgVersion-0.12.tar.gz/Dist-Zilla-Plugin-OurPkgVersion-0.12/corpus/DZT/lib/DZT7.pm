use strict;
use warnings;
package DZT7;
## VERSION
# ABSTRACT: my abstract
1;
