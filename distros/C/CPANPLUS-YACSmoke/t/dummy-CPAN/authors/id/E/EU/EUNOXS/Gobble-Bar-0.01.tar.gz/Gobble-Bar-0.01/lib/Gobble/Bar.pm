package Gobble::Bar;

use strict;
use warnings;
use Ass::Hat;
use vars qw($VERSION);

$VERSION = '0.01';

'Foo Bar!'

__END__
