CREATE TABLE news_section (
  news_section_id   %%INCREMENT%%,
  section           varchar(20) not null,
  primary key( news_section_id )
)